# Package initialization and global variables

# Suppress R CMD check notes for ggplot2 NSE
utils::globalVariables(c("Weight", "Feature", "Directionality"))

